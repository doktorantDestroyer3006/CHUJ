import os
import pyspark
from pyspark.ml import Pipeline
from pyspark.mllib.evaluation import MulticlassMetrics
import numpy
from docker_logs import get_logger
from pyspark.ml.feature import OneHotEncoderEstimator, VectorAssembler, StringIndexer
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, RegressionEvaluator, BinaryClassificationEvaluator
import pyspark.sql.functions as f
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.regression import LinearRegression
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.linalg import Vectors
from pyspark.ml.stat import Correlation

logging = get_logger('task')

os.environ['PYSPARK_SUBMIT_ARGS'] =\
        '--packages org.mongodb.spark:mongo-spark-connector_2.11:2.2.- pyspark-shell'

spark = pyspark.sql.SparkSession.builder \
    .appName('test-mongo') \
    .config('spark.mongodb.input.uri', 'mongodb://database//database.tweet') \
    .config('spark.mongodb.output.uri', 'mongodb://database/database.tweet') \
    .getOrCreate()

def load_data():
    df = spark.read \
        .format('com.mongodb.spark.sql.DefaultSource') \
        .load()
    df.printSchema()
    return df

def preprocess_data(df):
    df = df.withColumn('text_len', f.length('text'))
    return df

def binary_classification(tweet_df):
    tweet_df = tweet_df.withColumn('label', tweet_df.hashtags.cast('integer'))
    numericCols = ['comments_nr', 'text_len']
    assembler = VectorAssembler(inputCols=numericCols, outputCol='features')
    pipeline = Pipeline(stages=[assembler])
    pipelineModel = pipeline.fit(tweet_df)
    df = pipelineModel.transform(tweet_df)
    selectedCols = ['label', 'features']
    df = df.select(selectedCols)
    # df.printSchema()
    train, test = df.randomSplit([0.8, 0.3], seed=0)
    lr = LogisticRegression(geaturesCol='features', labelCol='label',
                            maxIter=20)
    lrModel = lr.fit(train)
    predictions = lrModel.transform(test)
    evaluator = BinaryClassificationEvaluator()

def regression(tweet_df):
    vectorAssembler = VectorAssembler(inputCols=['text_len'],
                                      outputCol='features')
    v_sub = vectorAssembler.transform(tweet_df)
    v_sub = v_sub.select(['features', 'hashtags'])
    splits = v_sub.randomSplit(['0.8, 0.3'])
    train_df = splits[0]
    test_df = splits[1]
    lr = LinearRegression(featuresCol = 'features', labelCol = 'hashtags',
                          maxIter = 20, regParam = 0.2, elasticNetParam = 0.7)
    lr_model = lr.fit(train_df)
    # trainingSummary = lr_model.summary
    # train_df.describe().show()
    lr_predictions = lr_model.transform(test_df)
    lr_evaluator = RegressionEvaluator(predictionCol='prediction', \
                                       labelCol='hashtags', metricName='R2')
    test_results = lr_model.evaluate(test_df)


def multiclass_classification(tweet_df):
    assembler = VectorAssembler(inputCols=['comments_nr', 'text_len'], outputCols='features')
    label_stringIdx = StringIndexer(inputCol='tweet', outputCol='label')
    pipeline = Pipeline(stages=[assembler, label_stringIdx])
    pipelineFit = pipeline.fit(submissions_df)
    dataset = pipeline.fit(sublissions_df)
    (trainingData, testData) = dataset.randomSplit([0.8, 0.2], seed=0)
    lr = LogisticRegression(maxIter=10, regParam=0.2, elasticNetParam=0)
    lrModel = lr.fit(trainingData)
    predictions =lrModel.transform(testData)
    evaluator = MulticlassCassificationEvaluator(predictionCol='prediction')

def main():
    df = load_data()
    df = preprocess_data(df)
    # df.describe().show()
    df.cube('tewwt').count().show()
    #regression(df)
    #binary_classification(df)
    #multiclass_classification(df)

if __name__ == '__main__':
    main()
