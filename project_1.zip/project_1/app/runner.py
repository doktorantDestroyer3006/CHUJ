"""."""
from celery_base import task
from random import random
from docker_logs import get_logger
from time import sleep

logging = get_logger("runner")
logging.propagate = False

result = task.delay(random())

while not result.ready():
    sleep(1)

result = result.get(timeout=10)

logging.info(f"Task returned: {result}")
