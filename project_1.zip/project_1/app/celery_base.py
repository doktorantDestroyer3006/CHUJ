"""."""
from celery import Celery
from docker_logs import get_logger
import praw
import time
#from influxdb import InfluxDBClient
from datetime import datetime
import twint
from io import StringIO
import sys
from kombu import Queue

logging = get_logger("task")

app = Celery()
app.conf.task_default_queue = 'default'
app.conf.task_queues = (
    Queue('default', routing_key='worker.#'),
    Queue('embedding_tasks', routing_key='embedder.#'),
    Queue('mongodb_task', routing_key='mongodb_worker.#')
)


#reddit_client = praw.Reddit()

start_time = time.time()

#db_client = InfluxDBClient(host='influxdb', port='8086', database='database')
_submissions_schedule_delay = 30.0
_collected_subreddit_name = 'worldnews'
counter = 0
ftch = 0

c = twint.Config()
c.Search = 'corona'
c.Limit = 20

graphs = {}
graphs['cnt_sub'] = 0
graphs['cnt_req_t'] = []
graphs['cnt_req'] = 0
graphs['hist_request_time'] = []
graphs['hist_sub_len'] = []
# graphs['cnt_sub'] = Counter('fetched_submissions',
#                  'Fetched submissions amount')
# graphs['cnt_requests'] = Counter('reddit_api_requests',
#                        'Reddit api requests amount')

# graphs['hist_request_time'] = Histogram('requests_fetch_times',
#                     'Time required to fetch api request')
# graphs['hist_sub_len'] = Histogram('submission_len',
#                          'Submission length',
#                  buckets=[5, 10, 40, 100, 200, 1000])


@app.task(bind=True, name='task')
def task(self, param):
    """."""
    logging.info(f"Celery task executed with param: {param}")
    return f"Result of task for param {param}"


def get_last_submissions(subreddit_name, num_posts=30):
    """."""
    #subreddit = reddit_client.subreddit(subreddit_name)
    #new_submissions2 = [s for s in subreddit.new(limit=num_posts)]
    # if not 'cnt_sub' in graphs:
    #    graphs['cnt_sub'] = 0
    # graphs['cnt_req'] += 1
    # graphs['cnt_sub']

    # graphs['cnt_requests'].inc()
    graphs['hist_request_time'].append(time.time() - start_time)
    capture = StringIO()
    save_stdout = sys.stdout
    sys.stdout = capture
    twint.run.Search(c)
    sys.stdout = save_stdout
    # print(capture.getvalue())
    new_submissions = capture.getvalue().split('\n')[:-1]
    return new_submissions#, new_submissions2


@app.on_after_configure.connect
def setup_periodic_task(sender, **kwargs):
    """."""
    # Calls subreddit_collector(subreddit name)
    logging.info('Setting up periodic subreddit collector')

    sender.add_periodic_task(
        _submissions_schedule_delay,
        subreddit_collector.s(_collected_subreddit_name),
        name=f'Subm. collector run every {_submissions_schedule_delay}')


@app.task(bind=True, name='subreddit collector')
def subreddit_collector(self, subreddit_name):
    """."""
    # counter+=1
    logging.info('Downloading new submissions')

    current_time = time.time()
    global ftch
    ftch += 1
    last_submissions= get_last_submissions(subreddit_name, 30)
    # print('xd',last_submissions)i
    new_submissions = []
    for sub in last_submissions:
        q = ''
        subspl = sub.split()
        q += subspl[1]
        q += ' '
        q += subspl[2]
        q += '.0'
        date_time_obj = datetime.strptime(q, '%Y-%m-%d %H:%M:%S.%f')

        y = time.mktime(date_time_obj.timetuple())
        # print(current_time, y, current_time-y)
        if current_time - y < _submissions_schedule_delay:
            new_submissions.append(sub)
    # new_submissions = [sub for sub in last_submissions]
    # if current_time - sub.created_utc < _submissions_schedule_delay]
    # print('xd2',new_submissions)

    logging.info(f'No. of new subm.: {len(new_submissions)}')
    # for sub in last_submissions:
    #    graphs['hist_sub_len'].append(len(sub.title))
    # graphs['hist_sub_len'].observe(len(sub.title))
    # graphs['cnt_sub'] += len(new_submissions)

#    db_name = 'db0'
#    if db_name not in [db['name'] for db in db_client.get_list_database()]:
#        db_client.create_database('db0')
#    db_client.switch_database(db_name)

    records = []

    for s in new_submissions:
        global counter
        counter += 1
        idd = s.split()[0]
        author = s.split()[4][1:-1]
        tweet = s[len(idd) + 28 + len(author):]
        q=s.split()[1] + ' ' + s.split()[2]+'.0'
        date_time_obj = datetime.strptime(q, '%Y-%m-%d %H:%M:%S.%f')
        y = time.mktime(date_time_obj.timetuple())
        rr = {
            'measurement': 'tasks',
            'tags': {
                'user': 'admin'
            },
            'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'fields': {
                'id': s.split()[0],
                'hour': s.split()[2].split(':')[0], #hist
                'tweet_time': s.split()[1] + ' ' + s.split()[2],
                'tweet_POSIX': y,
                'author': s.split()[4][1:-1],
                'tweet': s[len(idd) + 28 + len(author):],
                'tweet_len': len(tweet), #hist
                'submission_number': counter, #count
                'fetch_number': ftch #count
            }
        }
        print(rr['fields']['tweet'])
        records.append(rr)

    #db_client.write_points(records)
    return {}
