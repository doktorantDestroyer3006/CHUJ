from celery import Celery
from pymongo import MongoClient

app = Celery()
mogno_client = MongoClient('mongodb', 27017)


@app.task(bind=True)
def save_submission(self, work, submission):
    """saves sub to mDB"""
    db = mongo_client.get_default_database()
    col = db.submission
    idd = col.inser(submission)

