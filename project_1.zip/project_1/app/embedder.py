import fasttext
from mongodb_worker import save_sub
from celery import Celery

app = Celery()

model_name = 'cc.bin'
ft_m = fasttext.load_model(model_name)


@app.task(bind=True)
def embedding(self, work, submissions):
    """Emb for subm"""
    for s in submissions:
        vec = ft_m.get_sentence_vector(s['fields']['tweet'])
        save_sub.apply_async(args=['mongodb_worker',vec],
                             queue='mongodb_task')
    pass


